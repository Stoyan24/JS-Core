let functions = require('./03. Load Data');

result.sort = functions.sort;
result.filter = functions.filter;